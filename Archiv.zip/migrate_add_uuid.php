<?php
/**
 * Add UUID field to contacts table for secure private profile URLs
 * 
 * IMPORTANT: Run this migration script ONCE when upgrading to UUID-based system
 * 
 * Usage: Access this file via browser: https://yoursite.com/migrate_add_uuid.php
 * After successful migration, delete this file for security.
 */

$host = 'localhost';
$user = 'easycontact';
$pass = 'EzC0nt@ct2025!';
$dbname = 'easycontact';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    
    echo "🔄 Adding UUID field to contacts table...\n";
    
    // Add UUID column
    $pdo->exec("ALTER TABLE contacts ADD COLUMN uuid CHAR(36) NULL AFTER id");
    echo "✅ UUID column added\n";
    
    // Add unique index
    $pdo->exec("ALTER TABLE contacts ADD UNIQUE KEY unique_uuid (uuid)");
    echo "✅ Unique index added\n";
    
    // Generate UUIDs for existing contacts
    $stmt = $pdo->query("SELECT id FROM contacts WHERE uuid IS NULL");
    $contacts = $stmt->fetchAll();
    
    $updateStmt = $pdo->prepare("UPDATE contacts SET uuid = ? WHERE id = ?");
    
    foreach ($contacts as $contact) {
        $uuid = sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
        
        $updateStmt->execute([$uuid, $contact['id']]);
    }
    
    echo "✅ Generated UUIDs for " . count($contacts) . " existing contacts\n";
    echo "🎉 Migration completed successfully!\n";
    
} catch (PDOException $e) {
    echo "❌ Database error: " . $e->getMessage() . "\n";
    exit(1);
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    exit(1);
}
?>